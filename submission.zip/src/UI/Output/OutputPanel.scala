package UI.Output

import java.awt.{Dimension, GridBagLayout}

import javax.swing.JPanel

class OutputPanel extends JPanel {

  setPreferredSize(new Dimension(1000, 800))
  setLayout(new GridBagLayout())

}
