import UI.MainGUI

object Main extends App {

  new MainGUI()

}
